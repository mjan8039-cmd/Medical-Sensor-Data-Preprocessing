
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import PowerTransformer
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split

# Load dataset
data = pd.read_csv("data/hrv_raw.csv")
print("Initial Dataset Shape:", data.shape)

# Handling missing values
data_interpolated = data.interpolate(method='linear')
data_filled = data_interpolated.fillna(data_interpolated.median())

# Outlier detection using Isolation Forest
iso = IsolationForest(contamination=0.05, random_state=42)
outliers = iso.fit_predict(data_filled)
data_no_outliers = data_filled[outliers == 1]
print("Shape after outlier removal:", data_no_outliers.shape)

# Feature scaling using PowerTransformer
scaler = PowerTransformer(method='yeo-johnson')
scaled_features = scaler.fit_transform(data_no_outliers)
scaled_df = pd.DataFrame(scaled_features, columns=data_no_outliers.columns)

# Noise reduction (Rolling mean)
smoothed_df = scaled_df.rolling(window=3, min_periods=1).mean()

# Dimensionality reduction (PCA)
pca = PCA(n_components=0.95)
pca_features = pca.fit_transform(smoothed_df)
print("Reduced dimensions after PCA:", pca_features.shape[1])

# Plot PCA variance
plt.figure()
plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel("Number of Components")
plt.ylabel("Cumulative Explained Variance")
plt.title("PCA Variance Retention")
plt.savefig("outputs/pca_variance.png")

# Train-test split
X_train, X_test = train_test_split(pca_features, test_size=0.2, random_state=42)
print("Training set shape:", X_train.shape)
print("Testing set shape:", X_test.shape)
print("Preprocessing completed successfully.")
